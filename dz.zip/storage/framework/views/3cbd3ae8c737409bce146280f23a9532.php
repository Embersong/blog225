<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home')]); ?>" href="<?php echo e(route('home')); ?>">Главная</a>
<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('posts.*')]); ?>" href="<?php echo e(route('posts.index')); ?>">Посты</a>

<?php if(auth()->guard()->check()): ?>
    <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('my-posts.*')]); ?>" href="<?php echo e(route('my-posts.index')); ?>">Мои Посты</a>
<?php endif; ?>

<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('about')]); ?>" href="<?php echo e(route('about')); ?>">О нас</a>
<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->is_admin): ?>
        <a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.*')]); ?>" href="<?php echo e(route('admin.home')); ?>">Админка</a>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('auth.logout')); ?>" class="inline-form">
        <button class="btn-link" type="submit">Выйти (<?php echo e(auth()->user()->name); ?>)</button>
    </form>
<?php else: ?>
    <a href="<?php echo e(route('auth.login')); ?>">Войти</a>
<?php endif; ?>

<br>
<?php /**PATH C:\OSpanel\domains\laravel\resources\views/components/menu.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'crud posts'); ?>

<?php $__env->startSection('content'); ?>
    <h2>CRUD постов</h2>
    <a href="<?php echo e(route('admin.posts.create')); ?>">Создать пост</a><br>
    <?php if($posts->isEmpty()): ?>
        <p>Постов пока нет.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>№</th>
                <th>Заголовок</th>
                <th>Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn btn-primary">Правка</a>
                            <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">Удалить</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($posts->links('components.minimal')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/admin/index.blade.php ENDPATH**/ ?>

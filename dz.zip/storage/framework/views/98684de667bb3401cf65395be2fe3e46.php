<?php if(session('success')): ?>
    <p style="color:green"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if(session('error')): ?>
    <p style="color:red"><?php echo e(session('error')); ?></p>
<?php endif; ?>
<?php /**PATH C:\OSpanel\domains\laravel\resources\views/components/alerts.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Создание поста'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Создание поста</h2>

    <?php echo $__env->make('my-posts._form', [
    'post' => null
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/my-posts/create.blade.php ENDPATH**/ ?>
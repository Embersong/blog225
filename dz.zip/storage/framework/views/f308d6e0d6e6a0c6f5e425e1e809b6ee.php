<?php $__env->startSection('title', 'CRUD категорий'); ?>

<?php $__env->startSection('content'); ?>
    <h2>CRUD категорий</h2>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">Создать категорию</a><br>

    <?php if($categories->isEmpty()): ?>
        <p>Категорий пока нет.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>№</th>
                <th>Название</th>
                <th>Slug</th>
                <th>Описание</th>
                <th>Постов</th>
                <th>Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->slug); ?></td>
                    <td><?php echo e($category->description ?? '-'); ?></td>
                    <td><?php echo e($category->posts_count); ?></td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-primary">Правка</a>
                            <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">Удалить</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($categories->links('components.minimal')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('home')]); ?>" href="<?php echo e(route('home')); ?>">Главная блог</a>
<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.home')]); ?>" href="<?php echo e(route('admin.home')); ?>">Админка</a>
<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.posts.*')]); ?>" href="<?php echo e(route('admin.posts.index')); ?>">CRUD Посты</a>
<a class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('admin.categories.*')]); ?>" href="<?php echo e(route('admin.categories.index')); ?>">CRUD Категории</a>
<br>
<?php /**PATH C:\OSpanel\domains\laravel\resources\views/components/admin/menu.blade.php ENDPATH**/ ?>
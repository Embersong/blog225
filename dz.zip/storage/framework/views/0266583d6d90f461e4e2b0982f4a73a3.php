<?php $__env->startSection('title', 'Посты'); ?>

<?php $__env->startSection('content'); ?>
    <h2><?php echo e($post->title); ?></h2>
    <p><strong>Категория:</strong> <?php echo e($post->category->name ?? '-'); ?></p>
    <p><strong>Автор:</strong> <?php echo e($post->user->name ?? '-'); ?></p>

    <?php if($post->image): ?>
        <img style="width: 200px" src="<?php echo e(Storage::url($post->image)); ?>" alt="<?php echo e($post->title); ?>" class="post-image">
    <?php endif; ?>

    <p><?php echo e($post->content); ?></p>

    <p>
        <button id="like-button" data-url="<?php echo e(route('api.posts.like', $post)); ?>">
            Like: <span id="like-count"><?php echo e($post->likes); ?></span>
        </button>
    </p>

    <h3>Комментарии (<?php echo e($post->comments->count()); ?>)</h3>

    <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div>
            <p>
                <strong><?php echo e($comment->user->name ?? 'Аноним'); ?></strong>
                <small><?php echo e($comment->created_at->format('d.m.Y H:i')); ?></small>
            </p>
            <p><?php echo e($comment->comment); ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Комментариев пока нет.</p>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <h3>Оставить комментарий</h3>

        <form action="<?php echo e(route('comments.store', $post)); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="comment">Комментарий</label>
                <textarea name="comment" id="comment" class="form-control" rows="4"><?php echo e(old('comment')); ?></textarea>
                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary">Отправить</button>
        </form>
    <?php else: ?>
        <p><a href="<?php echo e(route('auth.login')); ?>">Войдите</a>, чтобы оставить комментарий.</p>
    <?php endif; ?>
    <script>
        document.getElementById('like-button').addEventListener('click',
         async (event) => {
            const button = event.currentTarget;
            button.disabled = true;

            try {
                const response = await fetch(button.dataset.url, {
                    method: 'POST',
                    headers: {'Accept': 'application/json'}
                });

                if (response.ok) {
                    const data = await response.json();
                    document.getElementById('like-count').textContent = data.likes;

                }
            } finally {
                button.disabled = false;
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/posts/show.blade.php ENDPATH**/ ?>
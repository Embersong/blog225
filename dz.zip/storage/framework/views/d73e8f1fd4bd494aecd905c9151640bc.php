<?php $__env->startSection('title', 'Мои посты'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Мои посты</h2>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Post::class)): ?>
        <a href="<?php echo e(route('my-posts.create')); ?>" class="btn btn-primary">Создать пост</a><br>
    <?php endif; ?>

    <?php if($posts->isEmpty()): ?>
        <p>У вас пока нет постов.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>№</th>
                <th>Заголовок</th>
                <th>Категория</th>
                <th>Дата</th>
                <th>Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->category->name ?? '-'); ?></td>
                    <td><?php echo e($post->created_at?->format('d.m.Y H:i') ?? '-'); ?></td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <a href="<?php echo e(route('posts.show', $post)); ?>" class="btn btn-primary">Просмотр</a>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $post)): ?>
                                <a href="<?php echo e(route('my-posts.edit', $post)); ?>" class="btn btn-primary">Правка</a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $post)): ?>
                                <form action="<?php echo e(route('my-posts.destroy', $post)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger">Удалить</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($posts->links('components.minimal')); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/my-posts/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Войти'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Вход</h2>

    <form action="" method="POST" class="form">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>email<br>
                <input class="form-control" type="text" name="email" value="<?php echo e(old('email', 'admin@admin.ru')); ?>" autofocus>
            </label>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div class="form-group">
            <label>Пароль<br>
                <input class="form-control" type="password" name="password" value="123">
            </label>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label>
                <input type="checkbox" name="remember"> Запомнить меня
            </label>
        </div>

        <button type="submit" class="btn btn-primary">Войти</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>
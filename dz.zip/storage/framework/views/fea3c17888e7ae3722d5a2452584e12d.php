<?php $__env->startSection('title', 'Пост'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Категории</h2>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('posts.category', $category->slug)); ?>" title="<?php echo e($category->description); ?>">
            <?php echo e($category->name); ?>&nbsp;
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <h2>Фильтр</h2>

    <form action="<?php echo e(route('posts.index')); ?>" method="get">
        <div class="form-group">
            <label for="title">Поиск по заголовку</label>
            <input type="search" name="filter[title]" id="title" class="form-control" value="<?php echo e(request('filter.title')); ?>">
        </div>

        <div class="form-group">
            <label for="category">Категория</label>
            <select name="filter[category]" id="category" class="form-control">
                <option value="">Все категории</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php if((string) request('filter.category') === (string) $category->id): echo 'selected'; endif; ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="user">Автор</label>
            <select name="filter[user]" id="user" class="form-control">
                <option value="">Все авторы</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php if((string) request('filter.user') === (string) $user->id): echo 'selected'; endif; ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Применить</button>
        <a href="<?php echo e(route('posts.index')); ?>" class="btn">Сбросить</a>
    </form>

    <h2>Все посты</h2>
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a>
        Категория: <?php echo e($post->category->name ?? '-'); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Нет постов</p>
    <?php endif; ?>
    <?php echo e($posts->links('components.minimal')); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>
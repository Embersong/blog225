<?php $__env->startSection('title', 'Админка'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Добро пожаловать в админку</h2>

    <h3>Статистика</h3>
    <p>Всего категорий: <?php echo e($posts_categories_count); ?></p>
    <p>Всего постов: <?php echo e($posts_count); ?></p>

    <?php if($postsByCategory->isEmpty()): ?>
        <p>Категорий пока нет.</p>
    <?php else: ?>
        <table>
            <thead>
            <tr>
                <th>Категория</th>
                <th>Количество постов</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $postsByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->posts_count); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/admin/home.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'О нас'); ?>

<?php $__env->startSection('content'); ?>
    Звоните: 555-55-55
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSpanel\domains\laravel\resources\views/about.blade.php ENDPATH**/ ?>